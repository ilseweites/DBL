/**
 * INCOMPLETE 
 * Assignment 6 -- Prisoner's Dilemma -- 2ip90
 * part Patch
 * 
 * @author FILL IN
 * @author FILL IN
 * assignment group FILL IN
 * 
 * assignment copyright Kees Huizing
 */
import java.awt.*;

class Patch extends Button {
    private boolean cooperating;
    private double score;
    private boolean changeStrategy;
    private boolean justChanged;
    Patch[] neighbours = new Patch[9];
    
    // returns true if and only if patch is cooperating
    boolean isCooperating() {
        return this.cooperating;
    }
    
    // set strategy to C if isC is true and to D if false
    void setCooperating(boolean isC) {
        this.cooperating = isC;
        if(this.cooperating) {
            this.setBackground(Color.BLUE);
        } else {
            this.setBackground(Color.RED);
        }
    }
    
    // change strategy from C to D and vice versa
    void toggleStrategy() {
        this.cooperating = !cooperating;
        this.justChanged = true;
    }

    void setChangeStrategy(boolean bool) {
        this.changeStrategy = bool;
    }

    boolean changedStrategy() {
        return this.changeStrategy;
    }

    public boolean getJustChanged() {
        return this.justChanged;
    }
    
    // return score of this patch in current round
    double getScore() {
        return this.score;
    }

    void setScore(double score) {
        this.score = this.score + score;
    }

    void resetScore() {
        this.score = 0.0;
    }
}
