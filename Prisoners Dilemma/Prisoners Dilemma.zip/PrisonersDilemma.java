/**
 * INCOMPLETE
 * Assignment 6 -- Prisoner's Dilemma -- 2ip90
 * main class
 * 
 * @author FILL IN
 * @author FILL IN
 * assignment group FILL IN
 * 
 * assignment copyright Kees Huizing
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.util.Hashtable;

class PrisonersDilemma /* possible extends... */ {
    private int timerDelay = 1000;
    
    void buildGUI() {
        SwingUtilities.invokeLater( () -> {
            //creating the frame
            JFrame frame = new JFrame("Prisoner's dilemma");
            frame.setVisible(true);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setResizable(false);
            frame.setSize(500, 500);
            frame.setLayout(new BorderLayout());

            //creates playingfield
            PlayingField playingfield = new PlayingField();
            playingfield.fillGrid();
            playingfield.setLayout(new GridLayout(playingfield.getGridWidth(), playingfield.getGridLength()));
            playingfield.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
            playingfield.randomPatch();

            playingfield.addNeighbours();
            for (int x = 0 ; x < playingfield.getGridWidth(); x++){
                for (int y = 0 ; y < playingfield.getGridLength(); y++){
                    Patch patch;
                    patch = playingfield.getPatch(x, y);
                    patch.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            patch.toggleStrategy();
                        }
                    });  
                    playingfield.add(playingfield.getPatch(x,y));
                }
            }
            frame.add(playingfield,BorderLayout.CENTER);

            ActionListener taskPerformer = new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    playingfield.step();
                }
            };

            Timer timer = new Timer(timerDelay, taskPerformer);

            //creates panel for buttons
            JPanel buttons = new JPanel();
            buttons.setLayout(new GridLayout(4,2));
            buttons.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
            frame.add(buttons, BorderLayout.SOUTH);

            //creates go button
            JButton goButton = new JButton("Go");
            goButton.addActionListener(new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (timer.isRunning()) {
                        timer.stop();
                    } else {
                        timer.start();
                    }
                    if (goButton.getText().equals("Go")){
                        goButton.setText("Pause");
                    } else {
                        goButton.setText("Go");
                    } 
                }
            });

            JButton resetButton = new JButton("Reset");
            resetButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    playingfield.randomPatch();
                }
            });

            JLabel alphaLabel = new JLabel("Reward alpha: ");
            JSlider alphaSlider = new JSlider(0, 30, 10);
            alphaSlider.setMajorTickSpacing(1);
            alphaSlider.setPaintTicks(true);
            alphaSlider.setPaintLabels(true);
            Hashtable labelTable = new Hashtable();
            labelTable.put(0 , new JLabel("0.0") );
            labelTable.put(10, new JLabel("1.0") );
            labelTable.put(20, new JLabel("2.0") );
            labelTable.put(30, new JLabel("3.0") );
            alphaSlider.setLabelTable(labelTable);

            alphaSlider.addChangeListener(new ChangeListener() {
                @Override
                public void stateChanged(ChangeEvent e) {
                    JSlider source = (JSlider)e.getSource();
                    playingfield.setAlpha(source.getValue()/10.0); // changing alpha according tho the value of the slider /10.0
                    alphaLabel.setText(" Reward α: " + playingfield.getAlpha());
                }
            });

            //adds components to button panel
            buttons.add(alphaLabel);
            buttons.add(alphaSlider);
            buttons.add(goButton);      
            buttons.add(resetButton);
        } );
    }
    
    public static void main( String[] a ) {
        (new PrisonersDilemma()).buildGUI();
    }
}
